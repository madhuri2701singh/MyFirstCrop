import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.ensemble import RandomForestClassifier

# Load dataset
data = pd.read_csv(r"C:\Users\HP\Downloads\Crop_recommendation.csv")  # Ensure you have this dataset

# Features & target
X = data.drop("label", axis=1)
y = data["label"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scaling
sc = StandardScaler()
mx = MinMaxScaler()

X_train_scaled = sc.fit_transform(X_train)
X_test_scaled = sc.transform(X_test)

X_train_final = mx.fit_transform(X_train_scaled)
X_test_final = mx.transform(X_test_scaled)

# Train model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train_final, y_train)

# Save the model & scalers
pickle.dump(model, open("model.pkl", "wb"))
pickle.dump(sc, open("standscaler.pkl", "wb"))
pickle.dump(mx, open("minmaxscaler.pkl", "wb"))

print("Model training complete & saved!")
