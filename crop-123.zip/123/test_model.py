import pickle
import numpy as np

# Load Model & Scalers
model = pickle.load(open('model.pkl', 'rb'))
sc = pickle.load(open('standscaler.pkl', 'rb'))
mx = pickle.load(open('minmaxscaler.pkl', 'rb'))

# Sample Test Input (Modify as needed)
test_input = np.array([[90, 42, 43, 20.87, 82.0, 6.5, 202.9]])  # Change values

# Apply Scaling
mx_features = mx.transform(test_input)
sc_mx_features = sc.transform(mx_features)

# Prediction
prediction = model.predict(sc_mx_features)[0]

# Crop Dictionary
crop_dict = {
    1: "Rice", 2: "Maize", 3: "Jute", 4: "Cotton", 5: "Coconut", 6: "Papaya",
    7: "Orange", 8: "Apple", 9: "Muskmelon", 10: "Watermelon", 11: "Grapes",
    12: "Mango", 13: "Banana", 14: "Pomegranate", 15: "Lentil", 16: "Blackgram",
    17: "Mungbean", 18: "Mothbeans", 19: "Pigeonpeas", 20: "Kidneybeans",
    21: "Chickpea", 22: "Coffee"
}

crop = crop_dict.get(prediction, "Unknown Crop")
print(f"Predicted Crop: {crop}")
